import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
#load the titanic dataset
url = "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"
df = pd.read_csv(url)
#generate basic information
print(df.info())
print(df.describe())
print(df.describe(include=['0']))
print(df.isnull().sum())
plt.figure(figsize=(10,6))
sns.heatmap(df.isnull(), cbar=False, cmap='viridis')
plt.title('Missing Values Heatmap')
plt.show()
#Distribution of numerical features
plt.figure(figsize=(10,6))
df.hist(bins=30, figsize=(20,15), layout=(2,3))
plt.tight_layout()
plt.show()
#Count plot for categorical features
plt.figure(figsize=(14,7))
plt.subplot(2,2,1)
sns.countplot(data=df, x='survived')
plt.title('Survival Count')
plt.subplot(2,2,2)
sns.countplot(data=df, x='Pclass')
plt.title('Passenger class Distribution')
plt.subplot(2,2,3)
sns.countplot(data=df, x='sex')
plt.title('Gender Distribution')
plt.subplot(2,2,4)
sns.countplot(data=df, x='Embarked')
plt.title('Port of Embarkation Distribution')
plt.tight_layout()
plt.show()
#survival rate by Gender
plt.figure(figsize=(14,7))
plt.subplot(2,2,1)
sns.barplot(data=df, x='sex', y='Survived')
plt.title('Survival Rate by Gender')
#survival rate by class
plt.subplot(2,2,2)
sns.barplot(data=df, x='Pclass', y='Survived')
plt.title('Survival Rate by port of Embarkation')
#survival rate by Age
plt.subplot(2,2,3)
sns.histplot(data=df, x='Age', hue='Survived', bins=30, kde=True)
plt.title('Survival Rate by Age')
plt.tight_layout()
plt.show()
#Insights from visualizations and summary statistics
survived_counts = df['Survived'].value_counts()
pclass_counts = df['Pclass'].value_counts()
gender_survival = df.groupby('Sex')['Survived'].mean()
class_survival = df.groupby('Pclass')['Survived'].mean()
embarked_survival = df.groupby('Embarked')['Survived'].mean()
print(f"Survival Counts:\n{survived_counts}")
print(f"Passenger Class Counts:\n{pclass_counts}")
print(f"Survival Rate by Gender:\n{gender_survival}") 
print(f"Survival Rate by class:\n{class_survival}")
print(f"Survival Rate by embarked:\n{embarked_survival}")


